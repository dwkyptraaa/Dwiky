import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
import subprocess

# Membaca dataset
file_path = 'file_dataset.csv'
data = pd.read_csv(file_path)

# Daftar kolom yang akan diperbaiki
columns_with_zero_issue = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']

# Mengganti nilai 0 dengan NaN
data[columns_with_zero_issue] = data[columns_with_zero_issue].replace(0, np.nan)

# Mengisi nilai NaN dengan median
imputer = SimpleImputer(strategy='median')
data[columns_with_zero_issue] = imputer.fit_transform(data[columns_with_zero_issue])

# Menyimpan dataset yang sudah dibersihkan ke file Excel
output_file_path = 'dataset_cleaned.xlsx'
data.to_excel(output_file_path, index=False)

print(f"Dataset cleaned and saved to {output_file_path}")

# Menyimpan daftar paket Python ke file
requirements_file_path = 'dataset_cleaned.txt'
with open(requirements_file_path, 'w') as f:
    subprocess.run(['pip', 'freeze'], stdout=f)

print(f"Daftar paket Python disimpan ke {requirements_file_path}")
