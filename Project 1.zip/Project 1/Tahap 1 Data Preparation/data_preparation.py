import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

file_path = 'file_dataset.csv'
data = pd.read_csv(file_path)

columns_with_zero_issue = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']

data[columns_with_zero_issue] = data[columns_with_zero_issue].replace(0, np.nan)

imputer = SimpleImputer(strategy='median')
data[columns_with_zero_issue] = imputer.fit_transform(data[columns_with_zero_issue])

output_file_path = 'dataset_cleaned.xlsx'
data.to_excel(output_file_path, index=False)

print(f"Dataset cleaned and saved to {output_file_path}")
