import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import subprocess

# 1. Memuat Dataset
file_path = 'file_dataset.csv'
data = pd.read_csv(file_path)

# 2. Memahami Data
print("Lihat Sekilas Data:")
print(data.head())
print("\nInfo Data:")
print(data.info())
print("\nStatistik Deskriptif:")
print(data.describe())

# 3. Analisis Univariate
# Distribusi Fitur
plt.figure(figsize=(15, 10))
data.hist(bins=30, figsize=(15, 10), color='blue', alpha=0.7)
plt.suptitle('Distribusi Fitur')
plt.show()

# 4. Analisis Bivariate
# Korelasi
plt.figure(figsize=(12, 8))
sns.heatmap(data.corr(), annot=True, fmt='.2f', cmap='coolwarm')
plt.title('Matriks Korelasi')
plt.show()

# Visualisasi Pairplot
if 'Outcome' in data.columns:  # Pastikan kolom 'Outcome' ada
    sns.pairplot(data, hue='Outcome')
    plt.suptitle('Pairplot Fitur berdasarkan Outcome', y=1.02)
    plt.show()

# 5. Analisis Kategori
# Proporsi Hasil
if 'Outcome' in data.columns:  # Pastikan kolom 'Outcome' ada
    plt.figure(figsize=(8, 6))
    sns.countplot(x='Outcome', data=data)
    plt.title('Proporsi Pasien Diabetes')
    plt.xlabel('Outcome (0 = Tidak Diabet, 1 = Diabet)')
    plt.ylabel('Jumlah')
    plt.show()

# 6. Menyimpan daftar paket Python ke file
requirements_file_path = 'dataset_clean.txt'
with open(requirements_file_path, 'w') as f:
    subprocess.run(['pip', 'freeze'], stdout=f)

print(f"Daftar paket Python disimpan ke {requirements_file_path}")
