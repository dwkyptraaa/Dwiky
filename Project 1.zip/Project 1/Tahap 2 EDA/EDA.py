import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Memuat Dataset
data = pd.read_csv('file_dataset.csv')

# 2. Memahami Data
print("Lihat Sekilas Data:")
print(data.head())
print("\nInfo Data:")
print(data.info())
print("\nStatistik Deskriptif:")
print(data.describe())

# 3. Analisis Univariate
# Distribusi Fitur
plt.figure(figsize=(15, 10))
data.hist(bins=30, figsize=(15, 10), color='blue', alpha=0.7)
plt.suptitle('Distribusi Fitur')
plt.show()

# 4. Analisis Bivariate
# Korelasi
plt.figure(figsize=(12, 8))
sns.heatmap(data.corr(), annot=True, fmt='.2f', cmap='coolwarm')
plt.title('Matriks Korelasi')
plt.show()

# Visualisasi Pairplot
sns.pairplot(data, hue='Outcome')
plt.title('Pairplot Fitur berdasarkan Outcome')
plt.show()

# 5. Analisis Kategori
# Proporsi Hasil
plt.figure(figsize=(8, 6))
sns.countplot(x='Outcome', data=data)
plt.title('Proporsi Pasien Diabetes')
plt.xlabel('Outcome (0 = Tidak Diabet, 1 = Diabet)')
plt.ylabel('Jumlah')
plt.show()
