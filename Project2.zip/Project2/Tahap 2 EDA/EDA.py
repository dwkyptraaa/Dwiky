import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import subprocess

# 1. Memuat Dataset
data = pd.read_csv('Tahap 2 EDA\Sales_with_NaNs_v1.3.csv')

# 2. Memahami Data
print("Lihat Sekilas Data:")
print(data.head())
print("\nInfo Data:")
print(data.info())
print("\nStatistik Deskriptif:")
print(data.describe())

# 3. Analisis Univariate
# Distribusi Fitur Numerik
numerical_columns = ['Sales_Before', 'Sales_After', 'Customer_Satisfaction_Before', 'Customer_Satisfaction_After']
plt.figure(figsize=(15, 10))
data[numerical_columns].hist(bins=30, figsize=(15, 10), color='blue', alpha=0.7)
plt.suptitle('Distribusi Fitur Numerik')
plt.show()

# 4. Analisis Korelasi Antar Fitur Numerik
plt.figure(figsize=(12, 8))
sns.heatmap(data[numerical_columns].corr(), annot=True, fmt='.2f', cmap='coolwarm')
plt.title('Matriks Korelasi Antar Fitur Numerik')
plt.show()

# 5. Analisis Kategori
# Distribusi `Purchase_Made`
plt.figure(figsize=(8, 6))
sns.countplot(x='Purchase_Made', data=data, palette='viridis', order=data['Purchase_Made'].dropna().value_counts().index)
plt.title('Distribusi Purchase Made (Pembelian Dilakukan)')
plt.xlabel('Purchase Made')
plt.ylabel('Jumlah')
plt.show()

# Distribusi `Group`
plt.figure(figsize=(8, 6))
sns.countplot(x='Group', data=data, palette='viridis', order=data['Group'].dropna().value_counts().index)
plt.title('Distribusi Group (Control vs Treatment)')
plt.xlabel('Group')
plt.ylabel('Jumlah')
plt.show()

# 6. Pairplot Fitur Numerik berdasarkan Group
# Membersihkan data untuk pairplot
cleaned_data = data[numerical_columns + ['Group']].dropna()
sns.pairplot(cleaned_data, hue='Group', vars=numerical_columns, palette='husl', corner=True)
plt.suptitle('Pairplot Fitur Berdasarkan Group (Setelah Membersihkan Data)', y=1.02)
plt.show()

# 7. Menyimpan daftar paket Python ke file
requirements_file_path = 'dataset_clean.txt'
with open(requirements_file_path, 'w') as f:
    subprocess.run(['pip', 'freeze'], stdout=f)

print(f"Daftar paket Python disimpan ke {requirements_file_path}")
